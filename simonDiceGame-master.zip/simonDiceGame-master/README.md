# simonDiceGame
memory game
